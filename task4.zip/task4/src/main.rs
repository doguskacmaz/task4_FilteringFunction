
use std::any::Any;
use std::any::type_name;

fn main() {

    let my_vec :Vec<Box<dyn Any>> = vec![Box::new(23), Box::new(58.0), Box::new("tt")];
    

    let new_type:FilterCondition = FilterCondition::new("i32");

    let bool_vec: Vec<bool> = new_type.is_match(&my_vec);

    let filtered_vec = custom_filter(&my_vec,&new_type);
        
    println!("The boolean vector is {:?}", bool_vec);

    println!("The filtered vector is {:?}", filtered_vec);
    
}


enum MultiType {
    Integer(i32),
    Float(f64),
    Text(String),
}



struct FilterCondition{

    desired_type: String,

}



impl FilterCondition{

    fn new(desired_type:  String) -> Self {
        FilterCondition { desired_type }
    }
    fn is_match (&self, my_vec: &Vec<Box<dyn Any>>) -> Vec<bool> {
        
        my_vec.iter().map(|item| self.check_type(item)).collect()
    }

    fn check_type(&self, item: &Box<dyn Any>) -> bool {
        if self.desired_type == "i32" && item.downcast_ref::<i32>().is_some() {
            return true;
        }
        if self.desired_type == "f64" && item.downcast_ref::<f64>().is_some() {
            return true;
        }
        if self.desired_type == "String" && item.downcast_ref::<&str>().is_some() {
            return true;
        }
        false
    }    
}


    





fn custom_filter<T>(my_vec: &Vec<T>, new_type: &FilterCondition) -> Vec<T>

where
    T : Clone,
{
        my_vec
            .iter()
            .filter(|_item| type_name::<T>() == new_type.desired_type)
            .cloned()
            .collect();
    
}



